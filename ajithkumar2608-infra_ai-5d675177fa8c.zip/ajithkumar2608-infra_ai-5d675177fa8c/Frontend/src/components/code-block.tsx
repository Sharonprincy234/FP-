// [file name]: code-block.tsx (updated to better handle terminal commands)
"use client";

import { useState } from "react";
import { Check, Copy, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface CodeBlockProps {
  code: string;
  language?: string;
  className?: string;
}

export function CodeBlock({ code, language = "bash", className }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Detect if the code is a terminal command (starts with $)
  const isTerminalCommand = language === 'bash' || code.trim().startsWith('$');
  
  // Format the code for display (remove the $ prefix for terminal commands)
  const displayCode = isTerminalCommand && code.trim().startsWith('$') 
    ? code.trim().substring(1).trim() 
    : code;

  return (
    <div className={cn("relative my-4 rounded-md bg-muted overflow-hidden border", className)}>
      <div className="flex items-center justify-between px-4 py-2 bg-muted-foreground/10 border-b">
        <div className="flex items-center gap-2">
          {isTerminalCommand && <Terminal className="h-3 w-3 text-muted-foreground" />}
          <span className="text-xs text-muted-foreground uppercase font-medium">
            {isTerminalCommand ? 'terminal' : language}
          </span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 text-muted-foreground hover:text-foreground"
          onClick={handleCopy}
        >
          {copied ? (
            <Check className="h-3 w-3" />
          ) : (
            <Copy className="h-3 w-3" />
          )}
          <span className="sr-only">Copy code</span>
        </Button>
      </div>
      <pre className="p-4 overflow-x-auto text-sm font-mono bg-muted/50">
        <code className="block">
          {isTerminalCommand && <span className="text-green-400 select-none">$ </span>}
          {displayCode}
        </code>
      </pre>
    </div>
  );
}


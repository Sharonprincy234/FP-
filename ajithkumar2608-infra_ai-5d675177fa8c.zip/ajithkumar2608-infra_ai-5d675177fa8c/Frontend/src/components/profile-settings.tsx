// [file name]: profile-settings.tsx (updated to show profile picture)
"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { updateProfile, updatePassword, reauthenticateWithCredential, EmailAuthProvider } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { Loader2, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface ProfileSettingsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const profileSchema = z.object({
  name: z.string().min(1, "Name is required."),
  currentPassword: z.string().optional(),
  newPassword: z.string().optional(),
  confirmPassword: z.string().optional(),
}).refine(data => {
  if (data.newPassword || data.confirmPassword) {
    return data.newPassword === data.confirmPassword;
  }
  return true;
}, {
  message: "New passwords do not match.",
  path: ["confirmPassword"],
}).refine(data => {
    if (data.newPassword) {
        return !!data.currentPassword;
    }
    return true;
}, {
    message: "Current password is required to set a new one.",
    path: ["currentPassword"],
});


type ProfileFormValues = z.infer<typeof profileSchema>;

export function ProfileSettings({ open, onOpenChange }: ProfileSettingsProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: "",
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  const { formState: { isSubmitting } } = form;

  useEffect(() => {
    if (user) {
      form.reset({
        name: user.displayName || "",
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    }
    if (!open) {
      setIsChangingPassword(false);
    }
  }, [user, form, open]);


  const onSubmit = async (data: ProfileFormValues) => {
    if (!user || !user.email) {
        toast({ variant: "destructive", title: "Error", description: "You must be logged in to update your profile." });
        return;
    };

    try {
      if (data.name !== user.displayName) {
        await updateProfile(user, { displayName: data.name });
        toast({ title: "Success", description: "Your name has been updated." });
      }

      if (isChangingPassword && data.newPassword && data.currentPassword) {
        const credential = EmailAuthProvider.credential(user.email, data.currentPassword);
        
        await reauthenticateWithCredential(user, credential);
        await updatePassword(user, data.newPassword);
        
        toast({ title: "Success", description: "Your password has been changed." });
        setIsChangingPassword(false);
      }
      
      if (!isChangingPassword || (isChangingPassword && data.newPassword)) {
        onOpenChange(false);
      }

    } catch (error: any) {
      console.error("Profile update error:", error);
      toast({ variant: "destructive", title: "An error occurred.", description: error.message });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Profile Settings</DialogTitle>
          <DialogDescription>
            Manage your account settings. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center justify-center mb-4">
          <Avatar className="h-20 w-20">
            {user?.photoURL ? (
              <AvatarImage src={user.photoURL} alt={user.displayName || "User"} />
            ) : null}
            <AvatarFallback>
              <User className="h-10 w-10" />
            </AvatarFallback>
          </Avatar>
        </div>
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 py-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="grid grid-cols-4 items-center gap-4">
                  <FormLabel className="text-right">Name</FormLabel>
                  <FormControl>
                    <Input {...field} className="col-span-3" />
                  </FormControl>
                  <FormMessage className="col-span-4 text-right" />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                Email
                </Label>
                <Input id="email" value={user?.email || ''} className="col-span-3" readOnly disabled />
            </div>

            <div className="border-t pt-4 mt-2">
              {!isChangingPassword ? (
                <Button type="button" variant="outline" onClick={() => setIsChangingPassword(true)} className="w-full">
                  Change Password
                </Button>
              ) : (
                <div className="grid gap-4">
                  <h3 className="text-lg font-medium">Change Password</h3>
                  <FormField
                    control={form.control}
                    name="currentPassword"
                    render={({ field }) => (
                      <FormItem className="grid grid-cols-4 items-center gap-4">
                        <FormLabel className="text-right">Current</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} className="col-span-3" />
                        </FormControl>
                        <FormMessage className="col-span-4 text-right" />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem className="grid grid-cols-4 items-center gap-4">
                        <FormLabel className="text-right">New</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} className="col-span-3" />
                        </FormControl>
                        <FormMessage className="col-span-4 text-right" />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem className="grid grid-cols-4 items-center gap-4">
                        <FormLabel className="text-right">Confirm</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} className="col-span-3" />
                        </FormControl>
                        <FormMessage className="col-span-4 text-right" />
                      </FormItem>
                    )}
                  />
                </div>
              )}
            </div>
            
            <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>
                    Close
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save changes
                </Button>
            </DialogFooter>
            </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

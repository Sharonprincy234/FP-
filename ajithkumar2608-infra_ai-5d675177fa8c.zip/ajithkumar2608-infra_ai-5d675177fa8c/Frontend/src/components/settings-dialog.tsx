// settings-dialog.tsx (updated with model selection)
"use client";

import { useTheme } from "@/components/theme-provider";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useAuth } from "@/hooks/use-auth";
import { selectModel, getSystemInfo } from "@/app/actions";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Cpu, Download, Check } from "lucide-react";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const accentColors = [
  { name: "blue", className: "theme-blue", color: "bg-blue-500" },
  { name: "red", className: "theme-red", color: "bg-red-500" },
  { name: "green", className: "theme-green", color: "bg-green-500" },
  { name: "yellow", className: "theme-yellow", color: "bg-yellow-500" },
  { name: "purple", className: "theme-purple", color: "bg-purple-500" },
];

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { theme, setTheme, accentColor, setAccentColor } = useTheme();
  const { user } = useAuth();
  const { toast } = useToast();
  const [systemInfo, setSystemInfo] = useState<any>(null);
  const [selectedModel, setSelectedModel] = useState("");
  const [isSelecting, setIsSelecting] = useState(false);

  useEffect(() => {
    if (open) {
      fetchSystemInfo();
    }
  }, [open]);

  const fetchSystemInfo = async () => {
    try {
      const info = await getSystemInfo();
      setSystemInfo(info);
      if (info.current_model) {
        setSelectedModel(info.current_model);
      }
    } catch (error) {
      console.error("Failed to fetch system info:", error);
      toast({ variant: "destructive", title: "Failed to fetch system info" });
    }
  };

  const handleModelSelect = async () => {
    if (!selectedModel) return;
    
    setIsSelecting(true);
    try {
      const result = await selectModel(selectedModel);
      if (result.success) {
        toast({ title: "Model selected successfully", description: result.message });
        fetchSystemInfo(); // Refresh system info
      } else {
        toast({ variant: "destructive", title: "Selection failed", description: result.error });
      }
    } catch (error) {
      console.error("Failed to select model:", error);
      toast({ variant: "destructive", title: "Selection failed", description: "An unexpected error occurred" });
    } finally {
      setIsSelecting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Customize the appearance and AI model preferences.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4">
          <div className="grid gap-3">
            <Label>Theme</Label>
            <RadioGroup value={theme} onValueChange={setTheme} className="flex gap-4">
              <Label className="flex items-center gap-2 cursor-pointer">
                <RadioGroupItem value="system" />
                System
              </Label>
              <Label className="flex items-center gap-2 cursor-pointer">
                <RadioGroupItem value="light" />
                Light
              </Label>
              <Label className="flex items-center gap-2 cursor-pointer">
                <RadioGroupItem value="dark" />
                Dark
              </Label>
            </RadioGroup>
          </div>
          <div className="grid gap-3">
            <Label>Accent Color</Label>
            <div className="flex gap-2">
              {accentColors.map((color) => (
                <Button
                  key={color.name}
                  variant={accentColor === color.className ? "default" : "outline"}
                  size="icon"
                  className={`h-8 w-8 rounded-full ${color.color}`}
                  onClick={() => setAccentColor(color.className)}
                />
              ))}
            </div>
          </div>
          
          {user && systemInfo && (
            <div className="grid gap-3">
              <Label htmlFor="ai-model">AI Model Selection</Label>
              <div className="flex gap-2">
                <Select value={selectedModel} onValueChange={setSelectedModel}>
                  <SelectTrigger id="ai-model" className="flex-1">
                    <SelectValue placeholder="Select a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {systemInfo.available_models?.map((model: string) => (
                      <SelectItem key={model} value={model}>
                        <div className="flex items-center gap-2">
                          {model}
                          {model === systemInfo.current_model && (
                            <Check className="h-3 w-3 text-green-500" />
                          )}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleModelSelect} 
                  disabled={isSelecting || !selectedModel || selectedModel === systemInfo.current_model}
                  className="flex items-center gap-2"
                >
                  {isSelecting ? "Selecting..." : "Select"}
                </Button>
              </div>
              {systemInfo && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Cpu className="h-4 w-4" />
                  <span>Current: {systemInfo.current_model || "Unknown"}</span>
                  <div className={`w-2 h-2 rounded-full ${systemInfo.status === "ready" ? "bg-green-500" : "bg-yellow-500"}`}></div>
                </div>
              )}
            </div>
          )}
          
          <div className="grid gap-3">
            <Label htmlFor="language">Language</Label>
            <Select defaultValue="auto-detect">
              <SelectTrigger id="language">
                <SelectValue placeholder="Select a language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto-detect">Auto-detect</SelectItem>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Spanish</SelectItem>
                <SelectItem value="fr">French</SelectItem>
                <SelectItem value="de">German</SelectItem>
                <SelectItem value="ja">Japanese</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button">Done</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

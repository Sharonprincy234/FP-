// chat-interface.tsx (updated with all API integration)
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Settings, User, MessageSquare, LogOut, LogIn, Trash2, Bot, Cpu, RefreshCw } from "lucide-react";
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarInset,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import { Button } from "@/components/ui/button";
import { ChatMessages, type Message } from "@/components/chat-messages";
import { MessageInput } from "@/components/message-input";
import { getAiResponse, upgradeModel, getSystemInfo, getConversation, clearConversation, selectModel, healthCheck, SystemInfo } from "@/app/actions";
import { Separator } from "@/components/ui/separator";
import { ProfileSettings } from "./profile-settings";
import { SettingsDialog } from "./settings-dialog";
import { useAuth } from "@/hooks/use-auth";
import { auth } from "@/lib/firebase";
import { LoginDialog } from "./login-dialog";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface Chat {
  id: string;
  title: string;
  messages: Message[];
}

const getAIDisplayName = (modelName: string | null): string => {
  if (!modelName) return "Biovus AI";
  
  if (modelName.toLowerCase().includes('llama')) return "Ajith";
  if (modelName.toLowerCase().includes('qwen')) return "Qwen";
  if (modelName.toLowerCase().includes('mistral')) return "Mistral";
  if (modelName.toLowerCase().includes('codegemma')) return "Code Expert";
  if (modelName.toLowerCase().includes('phi')) return "Phi";
  
  const modelParts = modelName.split(':');
  return modelParts[0] || "Biovus AI";
};

export function ChatInterface() {
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [chatToDelete, setChatToDelete] = useState<string | null>(null);
  const [systemInfo, setSystemInfo] = useState<SystemInfo | null>(null);
  const [aiDisplayName, setAiDisplayName] = useState("Biovus AI");
  const [refreshingSystem, setRefreshingSystem] = useState(false);

  useEffect(() => {
    if (chats.length === 0) {
      handleNewChat();
    }
    
    fetchSystemInfo();
    loadConversationHistory();
  }, [chats.length]);

  useEffect(() => {
    if (systemInfo?.current_model) {
      setAiDisplayName(getAIDisplayName(systemInfo.current_model));
    }
  }, [systemInfo]);

  const fetchSystemInfo = async () => {
    try {
      setRefreshingSystem(true);
      const info = await getSystemInfo();
      setSystemInfo(info);
    } catch (error) {
      console.error("Failed to fetch system info:", error);
      toast({ variant: "destructive", title: "Failed to fetch system info" });
    } finally {
      setRefreshingSystem(false);
    }
  };

  const loadConversationHistory = async () => {
    try {
      const conversation = await getConversation();
      if (conversation.messages && conversation.messages.length > 0) {
        const chat: Chat = {
          id: conversation.conversation_id,
          title: "Current Conversation",
          messages: conversation.messages.map((msg: any) => ({
            role: msg.type === 'user' ? 'user' : 'ai',
            content: msg.content,
            cached: msg.cached || false
          }))
        };
        setChats([chat]);
        setActiveChatId(chat.id);
      }
    } catch (error) {
      console.error("Failed to load conversation:", error);
    }
  };

  const handleGoHome = () => {
    const emptyChat = chats.find(chat => chat.messages.length === 0);
    if (emptyChat) {
      setActiveChatId(emptyChat.id);
    } else {
      handleNewChat();
    }
  }

  const handleNewChat = async () => {
    try {
      await clearConversation();
      
      const newChat: Chat = {
        id: Date.now().toString(),
        title: "New Chat",
        messages: [],
      };
      setChats(prevChats => [newChat, ...prevChats]);
      setActiveChatId(newChat.id);
      
      toast({ title: "New conversation started" });
    } catch (error) {
      console.error("Failed to clear conversation:", error);
      toast({ variant: "destructive", title: "Failed to start new conversation" });
    }
  };
  
  const handleDeleteChat = () => {
    if (!chatToDelete) return;

    setChats(prevChats => {
      const remainingChats = prevChats.filter(chat => chat.id !== chatToDelete);

      if (activeChatId === chatToDelete) {
        if (remainingChats.length > 0) {
          setActiveChatId(remainingChats[0].id);
        } else {
          const newChat: Chat = {
            id: Date.now().toString(),
            title: "New Chat",
            messages: [],
          };
          setActiveChatId(newChat.id);
          return [newChat];
        }
      }
      return remainingChats;
    });

    setChatToDelete(null);
  };

  const handleUpgradeModel = async () => {
    try {
      const result = await upgradeModel();
      if (result.success) {
        toast({ title: "Model upgraded successfully", description: result.message });
        fetchSystemInfo();
      } else {
        toast({ variant: "destructive", title: "Upgrade failed", description: result.error });
      }
    } catch (error) {
      console.error("Failed to upgrade model:", error);
      toast({ variant: "destructive", title: "Upgrade failed", description: "An unexpected error occurred" });
    }
  };

  const handleSelectModel = async (modelName: string) => {
    try {
      const result = await selectModel(modelName);
      if (result.success) {
        toast({ title: "Model selected", description: result.message });
        fetchSystemInfo();
      } else {
        toast({ variant: "destructive", title: "Failed to select model" });
      }
    } catch (error) {
      console.error("Failed to select model:", error);
      toast({ variant: "destructive", title: "Failed to select model" });
    }
  };

  const handleLogout = async () => {
    await auth.signOut();
  };

  const handleMessageSend = async (message: string) => {
    if (!activeChatId) return;

    setIsLoading(true);

    const updatedChats = chats.map(chat => {
      if (chat.id === activeChatId) {
        const newMessages: Message[] = [
          ...chat.messages, 
          { role: "user", content: message }
        ];

        const isFirstUserMessage = chat.messages.filter(m => m.role === 'user').length === 0;
        const newTitle = isFirstUserMessage ? (message.length > 25 ? message.substring(0, 22) + '...' : message) : chat.title;

        return { ...chat, title: newTitle, messages: newMessages };
      }
      return chat;
    });
    setChats(updatedChats);

    try {
      const aiResult = await getAiResponse(message);
      const aiResponseContent = aiResult.response;

      const finalChats = updatedChats.map(chat => {
        if (chat.id === activeChatId) {
          const currentMessages = chat.messages;
          return { 
            ...chat, 
            messages: [...currentMessages, { 
              role: "ai", 
              content: aiResponseContent,
              cached: aiResult.cached || false,
              model: aiResult.model,
              category: aiResult.category
            }] 
          };
        }
        return chat;
      });

      setChats(finalChats);
      
      // Refresh system info to get updated model status
      fetchSystemInfo();
      
    } catch (error) {
      console.error("Failed to get AI response:", error);
      toast({ variant: "destructive", title: "Failed to get response" });
    } finally {
      setIsLoading(false);
    }
  };
  
  const activeChat = chats.find(chat => chat.id === activeChatId);
  const hasMessages = activeChat && activeChat.messages.length > 0;

  return (
    <div className="h-screen flex">
      <SidebarProvider>
        <Sidebar className="flex flex-col h-full">
          <SidebarHeader className="p-4 pt-6 pb-4">
            <button onClick={handleGoHome} className="flex items-center gap-2 text-sidebar-foreground hover:text-sidebar-foreground">
              <div className="bg-primary text-primary-foreground rounded-full p-1">
                <Bot className="h-5 w-5" />
              </div>
              <h2 className="text-lg font-semibold">Biovus AI</h2>
            </button>
          </SidebarHeader>
          <div className="p-2 pt-4">
            <Button variant="default" className="w-full" onClick={handleNewChat}>
              <Plus className="mr-2 h-4 w-4" />
              New Chat
            </Button>
          </div>
          <SidebarContent className="flex-grow pt-0 overflow-y-auto">
            <SidebarMenu>
              {chats.map(chat => (
                <SidebarMenuItem key={chat.id} className="group/item">
                  <SidebarMenuButton
                    onClick={() => setActiveChatId(chat.id)}
                    isActive={chat.id === activeChatId}
                    className="w-full justify-start pr-8"
                  >
                    <MessageSquare />
                    <span className="truncate">{chat.title}</span>
                  </SidebarMenuButton>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 opacity-0 group-hover/item:opacity-100"
                    onClick={() => setChatToDelete(chat.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter>
            <div className="px-4 py-2 text-xs text-muted-foreground">
              {systemInfo && (
                <div className="space-y-2 mb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Cpu className="h-3 w-3" />
                      <span>{aiDisplayName}</span>
                      {systemInfo.status === "ready" ? (
                        <div className="w-2 h-2 rounded-full bg-green-500 ml-1"></div>
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-yellow-500 ml-1"></div>
                      )}
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-5 w-5"
                      onClick={fetchSystemInfo}
                      disabled={refreshingSystem}
                    >
                      <RefreshCw className={`h-3 w-3 ${refreshingSystem ? 'animate-spin' : ''}`} />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {systemInfo.available_models?.slice(0, 3).map(model => (
                      <Badge 
                        key={model} 
                        variant="secondary" 
                        className="text-xs cursor-pointer"
                        onClick={() => handleSelectModel(model)}
                      >
                        {getAIDisplayName(model)}
                      </Badge>
                    ))}
                    {systemInfo.available_models?.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{systemInfo.available_models.length - 3}
                      </Badge>
                    )}
                  </div>
                </div>
              )}
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full text-xs mb-2"
                onClick={handleUpgradeModel}
                disabled={isLoading}
              >
                Upgrade Model
              </Button>
            </div>
            <Separator className="my-2" />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full justify-start">
                  {user?.photoURL ? (
                    <Avatar className="h-5 w-5 mr-2">
                      <AvatarImage src={user.photoURL} alt={user.displayName || "User"} />
                      <AvatarFallback>
                        <User className="h-3 w-3" />
                      </AvatarFallback>
                    </Avatar>
                  ) : (
                    <User className="mr-2 h-5 w-5" />
                  )}
                  <span className="truncate">{user ? user.displayName || user.email : "Profile"}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 mb-2 ml-2" side="top" align="start">
                {user ? (
                  <>
                    <DropdownMenuItem onSelect={() => setIsProfileOpen(true)}>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onSelect={() => setIsSettingsOpen(true)}>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onSelect={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Logout</span>
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem onSelect={() => setIsLoginOpen(true)}>
                      <LogIn className="mr-2 h-4 w-4" />
                      <span>Login</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onSelect={() => setIsSettingsOpen(true)}>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        <SidebarInset className="flex flex-col h-full max-h-screen">
          {hasMessages ? (
            <>
              <div className="flex-grow overflow-hidden">
                <ChatMessages messages={activeChat?.messages || []} isLoading={isLoading} aiName={aiDisplayName} />
              </div>
              <div className="p-4 bg-background border-t">
                <MessageInput onSend={handleMessageSend} disabled={isLoading} />
                <p className="text-xs text-center text-muted-foreground mt-2">
                  {aiDisplayName} can make mistakes. Consider checking important information.
                </p>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full">
              <div className="flex flex-col items-center text-center">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-primary text-primary-foreground rounded-full p-2">
                    <Bot className="h-8 w-8" />
                  </div>
                  <h1 className="text-2xl font-bold">Hi, I'm {aiDisplayName}.</h1>
                </div>
                <p className="text-lg text-muted-foreground mb-8">How can I help you today?</p>
              </div>
              <div className="w-full max-w-2xl px-4">
                <MessageInput onSend={handleMessageSend} disabled={isLoading} isCentered />
                <p className="text-xs text-center text-muted-foreground mt-2">
                  {aiDisplayName} can make mistakes. Consider checking important information.
                </p>
              </div>
            </div>
          )}
        </SidebarInset>
      </SidebarProvider>
      
      <ProfileSettings open={isProfileOpen} onOpenChange={setIsProfileOpen} />
      <SettingsDialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen} />
      <LoginDialog open={isLoginOpen} onOpenChange={setIsLoginOpen} />

      <AlertDialog open={!!chatToDelete} onOpenChange={(open) => !open && setChatToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this chat history. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setChatToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteChat}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { auth } from "@/lib/firebase";
import { GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword, signInWithEmailAndPassword, RecaptchaVerifier, signInWithPhoneNumber, PhoneAuthProvider, type ConfirmationResult } from "firebase/auth";
import { useToast } from "@/hooks/use-toast";
import { Mail, Phone, Chrome, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface LoginDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function LoginDialog({ open, onOpenChange }: LoginDialogProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const { toast } = useToast();
  
  // Email/Password states
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  // Phone states
  const [countryCode, setCountryCode] = useState("1");
  const [localPhoneNumber, setLocalPhoneNumber] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [recaptchaVerifier, setRecaptchaVerifier] = useState<RecaptchaVerifier | null>(null);
  const [phoneAuthError, setPhoneAuthError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      onOpenChange(false);
      toast({ title: "Successfully signed in with Google." });
    } catch (error) {
      console.error("Google sign-in error:", error);
      toast({ variant: "destructive", title: "Google sign-in failed." });
    }
  };

  const handleEmailAuth = async () => {
    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, email, password);
        toast({ title: "Successfully signed up!" });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        toast({ title: "Successfully signed in!" });
      }
      onOpenChange(false);
    } catch (error: any) {
      console.error("Email auth error:", error);
      toast({ variant: "destructive", title: "Authentication Failed", description: error.message });
    }
  };

  const setupRecaptcha = () => {
    if (!recaptchaVerifier) {
      const verifier = new RecaptchaVerifier(auth, "recaptcha-container", {
        size: "invisible",
        callback: () => {
          // reCAPTCHA solved, allow signInWithPhoneNumber.
        },
      });
      setRecaptchaVerifier(verifier);
      return verifier;
    }
    return recaptchaVerifier;
  };
  
  const handlePhoneSignIn = async () => {
    try {
      setPhoneAuthError(null);
      
      // Validate phone number
      if (!localPhoneNumber.trim()) {
        toast({ variant: "destructive", title: "Please enter a phone number." });
        return;
      }
      
      // Format phone number properly
      const formattedPhoneNumber = `+${countryCode}${localPhoneNumber.replace(/\D/g, '')}`;
      
      // Validate the formatted number
      if (formattedPhoneNumber.length < 10) {
        toast({ variant: "destructive", title: "Please enter a valid phone number." });
        return;
      }

      const verifier = setupRecaptcha();
      const result = await signInWithPhoneNumber(auth, formattedPhoneNumber, verifier);
      setConfirmationResult(result);
      toast({ title: "Verification code sent." });
    } catch (error: any) {
      console.error("Phone sign-in error:", error);
      
      if (error.code === 'auth/operation-not-allowed') {
        setPhoneAuthError("Phone authentication is not enabled. Please use email or Google sign-in.");
        toast({ 
          variant: "destructive", 
          title: "Phone Sign-In Not Available",
          description: "Please use email or Google sign-in instead."
        });
      } else if (error.code === 'auth/invalid-phone-number' || error.message.includes('TOO_SHORT')) {
        toast({ 
          variant: "destructive", 
          title: "Invalid Phone Number", 
          description: "Please enter a valid phone number with country code." 
        });
      } else {
        toast({ 
          variant: "destructive", 
          title: "Phone Sign-In Failed", 
          description: error.message 
        });
      }
    }
  };

  const handleVerifyCode = async () => {
    if (confirmationResult) {
      try {
        await confirmationResult.confirm(verificationCode);
        onOpenChange(false);
        toast({ title: "Successfully signed in with phone number." });
      } catch (error: any) {
        console.error("Phone verification error:", error);
        toast({ variant: "destructive", title: "Verification Failed", description: error.message });
      }
    }
  };

  // Reset phone states when dialog closes
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setConfirmationResult(null);
      setLocalPhoneNumber("");
      setVerificationCode("");
      setPhoneAuthError(null);
    }
    onOpenChange(open);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{isSignUp ? "Sign Up" : "Log In"}</DialogTitle>
          <DialogDescription>
            {isSignUp
              ? "Create an account to get started."
              : "Access your account."}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="email" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="email"><Mail className="mr-2 h-4 w-4" /> Email</TabsTrigger>
            <TabsTrigger value="phone"><Phone className="mr-2 h-4 w-4" /> Phone</TabsTrigger>
            <TabsTrigger value="google"><Chrome className="mr-2 h-4 w-4" /> Google</TabsTrigger>
          </TabsList>
          
          <TabsContent value="email" className="py-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="m@example.com" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  required 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  required 
                />
              </div>
              <Button onClick={handleEmailAuth} className="w-full">
                {isSignUp ? "Sign Up" : "Log In"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="phone" className="py-4">
            <div id="recaptcha-container"></div>
            
            {phoneAuthError && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{phoneAuthError}</AlertDescription>
              </Alert>
            )}
            
            {!confirmationResult ? (
              <div className="grid gap-4">
                <div className="grid grid-cols-4 gap-2">
                  <div className="col-span-1">
                    <Label htmlFor="country-code">Code</Label>
                    <Input 
                      id="country-code" 
                      type="text" 
                      placeholder="1" 
                      value={countryCode} 
                      onChange={e => setCountryCode(e.target.value.replace(/\D/g, ''))}
                      className="text-center"
                    />
                  </div>
                  <div className="col-span-3">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input 
                      id="phone" 
                      type="tel" 
                      placeholder="1234567890" 
                      value={localPhoneNumber} 
                      onChange={e => setLocalPhoneNumber(e.target.value.replace(/\D/g, ''))}
                      required 
                    />
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  Example: +1 1234567890 (US/Canada)
                </div>
                <Button 
                  onClick={handlePhoneSignIn} 
                  className="w-full"
                  disabled={!!phoneAuthError}
                >
                  Send Verification Code
                </Button>
              </div>
            ) : (
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="code">Verification Code</Label>
                  <Input 
                    id="code" 
                    type="text" 
                    placeholder="123456" 
                    value={verificationCode} 
                    onChange={e => setVerificationCode(e.target.value)} 
                    required 
                  />
                </div>
                <Button onClick={handleVerifyCode} className="w-full">
                  Verify & Sign In
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="google" className="py-4">
            <Button onClick={handleGoogleSignIn} variant="outline" className="w-full">
              <Chrome className="mr-2 h-4 w-4" />
              Sign in with Google
            </Button>
          </TabsContent>
        </Tabs>

        <Separator className="my-2" />

        <div className="text-center">
          <Button
            variant="link"
            onClick={() => setIsSignUp(!isSignUp)}
          >
            {isSignUp
              ? "Already have an account? Log In"
              : "Don't have an account? Sign Up"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

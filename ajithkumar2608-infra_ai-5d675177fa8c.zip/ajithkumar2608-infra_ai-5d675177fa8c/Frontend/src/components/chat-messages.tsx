// chat-messages.tsx (updated with model and category badges)
"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Bot, User, Loader2, RefreshCcw } from "lucide-react";
import { useEffect, useRef } from "react";
import { CodeBlock } from "./code-block";
import { Badge } from "@/components/ui/badge";

export interface Message {
  role: "user" | "ai";
  content: string;
  cached?: boolean;
  model?: string;
  category?: string;
}

interface ChatMessagesProps {
  messages: Message[];
  isLoading: boolean;
  aiName?: string;
}

// Function to get AI display name based on model
const getAIDisplayName = (modelName: string | undefined): string => {
  if (!modelName) return "Biovus AI";
  
  if (modelName.toLowerCase().includes('llama')) return "Ajith";
  if (modelName.toLowerCase().includes('qwen')) return "Qwen";
  if (modelName.toLowerCase().includes('mistral')) return "Mistral";
  if (modelName.toLowerCase().includes('codegemma')) return "Code Expert";
  if (modelName.toLowerCase().includes('phi')) return "Phi";
  
  const modelParts = modelName.split(':');
  return modelParts[0] || "Biovus AI";
};

const extractCodeBlocks = (content: string): { text: string; isCode: boolean; language?: string }[] => {
  const parts = [];
  let lastIndex = 0;
  
  const codeBlockRegex = /```(\w+)?\s*([\s\S]*?)```/g;
  let match;
  
  while ((match = codeBlockRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ text: content.substring(lastIndex, match.index), isCode: false });
    }

    const language = match[1] || 'text';
    const code = match[2].trim();
    parts.push({ text: code, isCode: true, language });

    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    const remainingText = content.substring(lastIndex);
    const terminalCommandRegex = /(^|\n)(\s*)\$([^\n]+)/g;
    let terminalLastIndex = 0;
    let terminalMatch;
    
    while ((terminalMatch = terminalCommandRegex.exec(remainingText)) !== null) {
      if (terminalMatch.index > terminalLastIndex) {
        parts.push({ 
          text: remainingText.substring(terminalLastIndex, terminalMatch.index), 
          isCode: false 
        });
      }

      const command = terminalMatch[3].trim();
      parts.push({ text: command, isCode: true, language: 'bash' });

      terminalLastIndex = terminalMatch.index + terminalMatch[0].length;
    }

    if (terminalLastIndex < remainingText.length) {
      parts.push({ 
        text: remainingText.substring(terminalLastIndex), 
        isCode: false 
      });
    }
  }

  if (parts.length === 0) {
    return [{ text: content, isCode: false }];
  }

  return parts;
};

const linkifyText = (text: string): JSX.Element[] => {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const elements: JSX.Element[] = [];
  let lastIndex = 0;
  let match;

  while ((match = urlRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      elements.push(<span key={`text-${lastIndex}`}>{text.substring(lastIndex, match.index)}</span>);
    }

    const url = match[0];
    elements.push(
      <a 
        key={`link-${match.index}`} 
        href={url} 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-blue-600 hover:underline"
      >
        {url}
      </a>
    );

    lastIndex = match.index + url.length;
  }

  if (lastIndex < text.length) {
    elements.push(<span key={`text-${lastIndex}`}>{text.substring(lastIndex)}</span>);
  }

  return elements;
};

export function ChatMessages({ messages, isLoading, aiName = "Biovus AI" }: ChatMessagesProps) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading]);
  
  return (
    <ScrollArea className="h-full w-full" viewportRef={viewportRef}>
      <div className="p-4 md:p-6">
        <div className="flex flex-col gap-4">
          {messages.map((message, index) => {
            const messageParts = extractCodeBlocks(message.content);
            const displayName = message.role === 'ai' ? getAIDisplayName(message.model) : 'You';
            
            return (
              <div
                key={index}
                className={cn(
                  "flex items-start gap-3",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {message.role === "ai" && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      <Bot className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                )}
                <div className={cn(
                  "flex flex-col",
                  message.role === "user" ? "items-end" : "items-start"
                )}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-muted-foreground">
                      {displayName}
                    </span>
                    {message.role === 'ai' && message.category && (
                      <Badge variant="outline" className="text-xs">
                        {message.category.replace('_', ' ')}
                      </Badge>
                    )}
                  </div>
                  <Card
                    className={cn(
                      "max-w-[75%] rounded-2xl p-3 text-sm",
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-card"
                    )}
                  >
                    <CardContent className="p-0">
                      {messageParts.map((part, partIndex) => 
                        part.isCode ? (
                          <CodeBlock 
                            key={partIndex} 
                            code={part.text} 
                            language={part.language}
                            className="my-2"
                          />
                        ) : (
                          <div key={partIndex} style={{ whiteSpace: "pre-wrap" }}>
                            {linkifyText(part.text)}
                          </div>
                        )
                      )}
                    </CardContent>
                  </Card>
                  {message.role === "ai" && message.cached && (
                    <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                      <RefreshCcw className="h-3 w-3" />
                      <span>Cached response</span>
                    </div>
                  )}
                </div>
                {message.role === "user" && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      <User className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            );
          })}
          {isLoading && (
            <div className="flex items-start gap-3 justify-start">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <Bot className="h-5 w-5" />
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium text-muted-foreground mb-1">
                  {aiName}
                </span>
                <Card className="max-w-[75%] rounded-2xl p-3 text-sm bg-card">
                  <CardContent className="p-0 flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Thinking...</span>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
    </ScrollArea>
  );
}

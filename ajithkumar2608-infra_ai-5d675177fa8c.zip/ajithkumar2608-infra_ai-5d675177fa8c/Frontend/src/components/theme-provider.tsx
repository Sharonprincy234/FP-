"use client"

import * as React from "react"
import { ThemeProvider as NextThemesProvider, useTheme as useNextTheme } from "next-themes"
import { type ThemeProviderProps } from "next-themes/dist/types"

const ACCENT_COLOR_STORAGE_KEY = "accent-color-class";
const accentColors = [
  "theme-blue",
  "theme-red",
  "theme-green",
  "theme-yellow",
  "theme-purple",
];

type CustomThemeContextType = {
  accentColor: string;
  setAccentColor: (accentColor: string) => void;
};

const CustomThemeContext = React.createContext<CustomThemeContextType | undefined>(undefined);

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  const [accentColor, setAccentColor] = React.useState("theme-blue");

  React.useEffect(() => {
    const storedAccentColor = localStorage.getItem(ACCENT_COLOR_STORAGE_KEY);
    if (storedAccentColor && accentColors.includes(storedAccentColor)) {
      setAccentColor(storedAccentColor);
    }
  }, []);

  React.useEffect(() => {
    document.body.classList.remove(...accentColors);
    document.body.classList.add(accentColor);
    localStorage.setItem(ACCENT_COLOR_STORAGE_KEY, accentColor);
  }, [accentColor]);

  return (
    <NextThemesProvider {...props}>
      <CustomThemeContext.Provider value={{ accentColor, setAccentColor }}>
        {children}
      </CustomThemeContext.Provider>
    </NextThemesProvider>
  )
}

export const useTheme = () => {
  const nextTheme = useNextTheme();
  const customTheme = React.useContext(CustomThemeContext);

  if (customTheme === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }

  return { ...nextTheme, ...customTheme };
};

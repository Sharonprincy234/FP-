
"use client";

import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { cn } from "@/lib/utils";
import { Textarea } from "./ui/textarea";

const formSchema = z.object({
  message: z.string().min(1, "Message cannot be empty"),
});

type FormValues = z.infer<typeof formSchema>;

interface MessageInputProps {
  onSend: (message: string) => void;
  disabled: boolean;
  isCentered?: boolean;
}

export function MessageInput({ onSend, disabled, isCentered }: MessageInputProps) {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      message: "",
    },
  });

  const onSubmit: SubmitHandler<FormValues> = (data) => {
    onSend(data.message);
    form.reset();
  };
  
  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (!disabled && form.getValues("message")) {
        form.handleSubmit(onSubmit)();
      }
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={cn("flex items-start gap-2", isCentered && "justify-center")}>
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem className={cn("relative", !isCentered ? "flex-grow" : "w-[768px]")}>
              <FormControl>
                <Textarea
                  placeholder="Type your message..."
                  autoComplete="off"
                  {...field}
                  disabled={disabled}
                  onKeyDown={handleKeyDown}
                  className={cn(isCentered ? "h-28 pr-14" : "pr-12", "resize-none")}
                />
              </FormControl>
              <Button 
                type="submit" 
                size="icon" 
                disabled={disabled || !form.formState.isValid} 
                className={cn(
                  "absolute",
                   isCentered ? "right-4 bottom-4 h-10 w-10" : "right-2 top-1/2 h-8 w-8 -translate-y-1/2"
                )}
              >
                <Send className={cn(isCentered ? "h-5 w-5" : "h-4 w-4")} />
                <span className="sr-only">Send</span>
              </Button>
            </FormItem>
          )}
        />
      </form>
    </Form>
  );
}

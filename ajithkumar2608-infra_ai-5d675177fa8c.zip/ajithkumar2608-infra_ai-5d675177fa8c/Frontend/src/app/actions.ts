// actions.ts (updated with all API endpoints)
'use server';

export interface ChatOutput {
  response: string;
  message_id?: string;
  cached?: boolean;
  model?: string;
  category?: string;
  analysis?: any;
  timestamp?: string;
  conversation_id?: string;
}

export interface SystemInfo {
  status: string;
  current_model: string;
  available_models: string[];
  model_categories: string[];
  conversation_id: string;
  message_count: number;
  timestamp: string;
}

export interface Conversation {
  conversation_id: string;
  messages: any[];
  timestamp: string;
}

export interface ModelSelectionResult {
  success: boolean;
  message: string;
  model: string;
  timestamp: string;
}

export interface ClearConversationResult {
  success: boolean;
  message: string;
  new_conversation_id: string;
  timestamp: string;
}

// Use an environment variable for the host, defaulting to localhost for local dev.
const AI_HOST = process.env.LOCAL_AI_HOST || 'localhost';
const AI_PORT = process.env.LOCAL_AI_PORT || '5000';
const BASE_URL = `http://${AI_HOST}:${AI_PORT}`;

async function apiFetch(endpoint: string, options: RequestInit = {}) {
  const url = `${BASE_URL}${endpoint}`;
  
  try {
    console.log(`API Call: ${url}`);
    const res = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!res.ok) {
      const errorBody = await res.text();
      console.error(`API Error (${res.status}):`, errorBody);
      throw new Error(`HTTP error! status: ${res.status}, message: ${errorBody}`);
    }

    return await res.json();
  } catch (error) {
    console.error(`API Call failed to ${url}:`, error);
    throw error;
  }
}

export async function getAiResponse(message: string): Promise<ChatOutput> {
  if (!message) {
    return { response: "Please provide a message." };
  }

  try {
    const data = await apiFetch('/chat', {
      method: 'POST',
      body: JSON.stringify({ message }),
    });

    return {
      response: data.response,
      message_id: data.message_id,
      cached: data.cached,
      model: data.model,
      category: data.category,
      analysis: data.analysis,
      timestamp: data.timestamp,
      conversation_id: data.conversation_id
    };

  } catch (error) {
    console.error("Error calling AI service:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    
    if (errorMessage.includes('fetch failed') || errorMessage.includes('Failed to fetch')) {
      return { 
        response: `Connection failed. Could not connect to the AI service at ${BASE_URL}. Please ensure the server is running and the LOCAL_AI_HOST in your .env file is correct.` 
      };
    }
    
    return { response: `Sorry, I encountered an error: ${errorMessage}` };
  }
}

export async function getSystemInfo(): Promise<SystemInfo> {
  try {
    return await apiFetch('/system-info');
  } catch (error) {
    console.error("Error getting system info:", error);
    throw error;
  }
}

export async function getConversation(): Promise<Conversation> {
  try {
    return await apiFetch('/conversation');
  } catch (error) {
    console.error("Error getting conversation:", error);
    throw error;
  }
}

export async function clearConversation(): Promise<ClearConversationResult> {
  try {
    return await apiFetch('/conversation/clear', {
      method: 'POST'
    });
  } catch (error) {
    console.error("Error clearing conversation:", error);
    throw error;
  }
}

export async function selectModel(modelName: string): Promise<ModelSelectionResult> {
  try {
    return await apiFetch('/models/select', {
      method: 'POST',
      body: JSON.stringify({ model: modelName }),
    });
  } catch (error) {
    console.error("Error selecting model:", error);
    throw error;
  }
}

export async function healthCheck(): Promise<any> {
  try {
    return await apiFetch('/health');
  } catch (error) {
    console.error("Error with health check:", error);
    throw error;
  }
}

export async function upgradeModel(modelName: string = "llama3.1:8b"): Promise<{success: boolean, message: string, error?: string}> {
  try {
    return await apiFetch('/upgrade-model', {
      method: 'POST',
      body: JSON.stringify({ model: modelName }),
    });
  } catch (error) {
    console.error("Error upgrading model:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    return { success: false, message: `Failed to upgrade model: ${errorMessage}` };
  }
}
